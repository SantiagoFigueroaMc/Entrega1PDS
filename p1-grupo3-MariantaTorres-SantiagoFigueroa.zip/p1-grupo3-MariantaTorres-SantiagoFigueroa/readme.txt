Para ejecutar:
python SimuladorParticulas.py

Para seleccionar un archivo de input, cambiar linea 7 en SimuladorParticulas.py
Por defecto simulará input03.in, que va incluido.